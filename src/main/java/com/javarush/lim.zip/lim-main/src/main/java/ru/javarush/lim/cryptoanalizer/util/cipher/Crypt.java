package ru.javarush.lim.cryptoanalizer.util.cipher;

public interface Crypt {

  char encrypt(char input);

  char decrypt(char input);

}
