package ru.javarush.lim.cryptoanalizer.io;

import java.util.concurrent.BlockingQueue;
import ru.javarush.lim.cryptoanalizer.util.cipher.Crypt;

public class TransformStage implements PipelineStage {

  private final Crypt cipher;
  private final boolean decryptMode;
  private final BlockingQueue<Character> inputQueue;
  private final BlockingQueue<Character> outputQueue;
  private final char poisonPill;

  public TransformStage(Crypt cipher,
      boolean decryptMode,
      BlockingQueue<Character> inputQueue,
      BlockingQueue<Character> outputQueue,
      char poisonPill) {
    this.cipher = cipher;
    this.decryptMode = decryptMode;
    this.inputQueue = inputQueue;
    this.outputQueue = outputQueue;
    this.poisonPill = poisonPill;
  }

  @Override
  public void run() throws Exception {
    try {
      while (true) {
        char c = inputQueue.take();
        if (c == poisonPill) {
          break;
        }

        char transformed = !decryptMode ? cipher.encrypt(c) : cipher.decrypt(c);

        outputQueue.put(transformed);
      }
      outputQueue.put(poisonPill);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException("Поток трансформации был прерван", e);
    } catch (Exception e) {
      throw new IllegalStateException("Ошибка при трансформации символов", e);
    }
  }
}
