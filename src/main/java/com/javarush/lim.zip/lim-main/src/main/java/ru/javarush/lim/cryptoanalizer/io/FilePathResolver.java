package ru.javarush.lim.cryptoanalizer.io;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class FilePathResolver {

  private FilePathResolver() {

  }

  public static Path resolveOutputPath(Path userInputPath, Path inputFile, String algorithmName,
      boolean isDecrypt) {
    algorithmName = algorithmName.replace("Crypt", "");
    String baseName = inputFile.getFileName().toString();
    baseName = baseName.contains(".") ? baseName.substring(0, baseName.lastIndexOf('.')) : baseName;

    String prefix = isDecrypt ? "decrypted_" : "encrypted_";
    String extension = ".txt";
    String fileName = prefix + algorithmName + "_" + baseName;

    Path outputPath;

    if (Files.isDirectory(userInputPath)) {

      try {
        Files.createDirectories(userInputPath);
      } catch (IOException e) {
        throw new IllegalStateException("❌ Не удалось создать выходную папку: " + userInputPath, e);
      }
      outputPath = userInputPath.resolve(fileName + extension);
    } else {

      outputPath = userInputPath;
      try {
        Files.createDirectories(outputPath.getParent());
      } catch (IOException e) {
        throw new IllegalStateException(
            "❌ Не удалось создать родительскую папку для файла: " + outputPath, e);
      }
    }

    // 🔁 Проверка на существование и генерация уникального имени
    int counter = 1;
    while (Files.exists(outputPath)) {
      String numberedName = fileName + "_" + counter + extension;
      outputPath = outputPath.getParent().resolve(numberedName);
      counter++;
    }

    return outputPath;
  }
}
