package ru.javarush.lim.cryptoanalizer;

import java.nio.file.Path;
import java.util.Optional;
import ru.javarush.lim.cryptoanalizer.io.FilePathResolver;
import ru.javarush.lim.cryptoanalizer.io.IOPipelineManager;
import ru.javarush.lim.cryptoanalizer.io.InputConsole;
import ru.javarush.lim.cryptoanalizer.io.InputConsole.Flag;
import ru.javarush.lim.cryptoanalizer.util.alphabet.AlphabetSet.AlphabetData;
import ru.javarush.lim.cryptoanalizer.util.cipher.Crypt;
import ru.javarush.lim.cryptoanalizer.util.cipher.CryptKey;
import ru.javarush.lim.cryptoanalizer.util.logger.Logger;
import ru.javarush.lim.cryptoanalizer.util.logger.LoggerSingleton;
import ru.javarush.lim.cryptoanalizer.util.validator.FileValidator;
import ru.javarush.lim.cryptoanalizer.util.validator.OutputDirectoryValidator;

public class Controller {

  private static final Logger logger = LoggerSingleton.getInstance();
  private static final String TAG = "Controller";

  private final Crypt cipher;
  private final AlphabetData alphabet;

  public Controller(Crypt cipher, AlphabetData alphabet) {
    this.cipher = cipher;
    this.alphabet = alphabet;
  }

  public void run() {
    logger.debug(TAG, "Запуск контроллера");

    while (true) {
      String choice = InputConsole.getValidatedInput(
          Flag.USER,
          s -> Optional.of(s.trim()),
          "❌ Введите 1 — шифрование, 2 — дешифровка, 3 — выход."
      );

      switch (choice) {
        case "1" -> process(false);
        case "2" -> process(true);
        case "3" -> {
          logger.info("👋 Завершение работы");
          return;
        }
        default -> logger.warn(TAG, "Неверный выбор: " + choice);
      }
    }
  }

  private void process(boolean isDecrypt) {
    try {

      byte rawKey = InputConsole.getValidatedInput(
          Flag.KEY, InputConsole::rawKey, "❌ Недопустимый ключ. Введите число от -128 до 127.");

      CryptKey.getKey(rawKey, cipher);

      Path inputPath = InputConsole.getValidatedInput(
          Flag.PATH,
          s -> {
            try {
              return Optional.of(FileValidator.validate(s));
            } catch (Exception e) {
              return Optional.empty();
            }
          },
          "❌ Входной файл недоступен или некорректен."
      );

      // 📤 Выходная папка
      Path outputDir = InputConsole.getValidatedInput(
          Flag.PATH,
          s -> {
            try {
              return Optional.of(OutputDirectoryValidator.validate(s));
            } catch (Exception e) {
              return Optional.empty();
            }
          },
          "❌ Папка для вывода недоступна."
      );

      Path outputPath = FilePathResolver.resolveOutputPath(
          outputDir,
          inputPath,
          cipher.getClass().getSimpleName(),
          isDecrypt
      );

      IOPipelineManager.getInstance().execute(inputPath, outputPath, cipher, alphabet, isDecrypt);
      logger.success("✅ Готово! Результат: %s".formatted(outputPath));

    } catch (Exception e) {
      logger.exception(TAG, "❌ Ошибка при обработке", e);
    }
  }
}
