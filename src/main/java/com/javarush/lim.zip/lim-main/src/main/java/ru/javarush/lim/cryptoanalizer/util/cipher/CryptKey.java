package ru.javarush.lim.cryptoanalizer.util.cipher;

@FunctionalInterface
public interface CryptKey {

  void acceptKey(byte key);

  static void getKey(byte key, Crypt target) {

    if (target instanceof CryptKey cryptKeyTarget) {
      cryptKeyTarget.acceptKey(key); // передаём ключ
    } else {
      throw new IllegalArgumentException("Объект не реализует CryptKey");
    }
  }
}