package ru.javarush.lim.cryptoanalizer.util.alphabet;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface AlphabetSet {

  record AlphabetData(
      List<Character> alphabetList,
      Set<Character> alphabetSet,
      Map<Character, Integer> alphabetMap
  ) {

    public boolean contains(char c) {
      return alphabetSet.contains(c);
    }

    public int indexOf(char c) {
      return alphabetMap.getOrDefault(c, -1);
    }

    public char get(int index) {
      return alphabetList.get(index);
    }

    public int size() {
      return alphabetList.size();
    }
  }

  default AlphabetData buildRecord(List<Character> alphabet) {
    List<Character> immutable = List.copyOf(alphabet);
    Set<Character> filterSet = new HashSet<>(immutable);
    Map<Character, Integer> indexMap = new HashMap<>();
    for (int i = 0; i < immutable.size(); i++) {
      indexMap.put(immutable.get(i), i);
    }
    return new AlphabetData(immutable, filterSet, indexMap);
  }
}
