package ru.javarush.lim.cryptoanalizer.util.validator;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import ru.javarush.lim.cryptoanalizer.util.logger.Logger;
import ru.javarush.lim.cryptoanalizer.util.logger.LoggerSingleton;

public final class FileValidator {

  private static final Logger logger = LoggerSingleton.getInstance();
  private static final Set<String> ALLOWED_EXTENSIONS = Set.of("txt");

  private FileValidator() {
    throw new UnsupportedOperationException("Утилитный класс — создание экземпляра запрещено");
  }

  public static Path validate(String input) {
    Path path;
    try {
      path = Path.of(input);
    } catch (Exception e) {
      throw new IllegalArgumentException("❌ Неверный синтаксис пути: %s".formatted(input));
    }

    if (!path.isAbsolute()) {
      throw new IllegalArgumentException("❌ Путь должен быть абсолютным: %s".formatted(path));
    }

    if (!Files.exists(path)) {
      throw new IllegalArgumentException("❌ Файл не существует: %s".formatted(path));
    }

    if (!Files.isRegularFile(path)) {
      throw new IllegalArgumentException("❌ Путь не является файлом: %s".formatted(path));
    }

    if (!Files.isReadable(path)) {
      throw new IllegalArgumentException("❌ Нет доступа на чтение файла: %s".formatted(path));
    }

    String filename = path.getFileName().toString();
    int dotIndex = filename.lastIndexOf('.');
    if (dotIndex == -1) {
      throw new IllegalArgumentException("❌ У файла нет расширения: %s".formatted(filename));
    }

    String extension = filename.substring(dotIndex + 1).toLowerCase();
    if (!ALLOWED_EXTENSIONS.contains(extension)) {
      throw new IllegalArgumentException("❌ Недопустимое расширение: .%s".formatted(extension));
    }

    logger.success("✅ Файл прошёл все проверки: %s".formatted(path));
    return path;
  }
}
