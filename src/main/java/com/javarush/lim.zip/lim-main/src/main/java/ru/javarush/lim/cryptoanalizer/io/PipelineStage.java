package ru.javarush.lim.cryptoanalizer.io;

public interface PipelineStage {

  void run() throws Exception;
}
