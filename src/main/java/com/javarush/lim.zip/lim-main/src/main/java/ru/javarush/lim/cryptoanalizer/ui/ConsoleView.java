package ru.javarush.lim.cryptoanalizer.ui;


import ru.javarush.lim.cryptoanalizer.util.logger.Logger;
import ru.javarush.lim.cryptoanalizer.util.logger.LoggerSingleton;

public final class ConsoleView {

  private static final Logger logger = LoggerSingleton.getInstance();

  public static void showMenu() {
    logger.info("""
        ╔════════════════════════════════════════════════════════════════════════════╗
        ║                                                                            ║
        ║                      ДОБРО ПОЖАЛОВАТЬ В ШИФРАТОР                           ║
        ║                                                                            ║
        ║                         Шифрует и зашифровывает...                         ║
        ║                                                                            ║
        ╚════════════════════════════════════════════════════════════════════════════╝
        """);
  }

  public static void clearConsole() {
    try {
      if (System.getProperty("os.name").toLowerCase().contains("windows")) {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
      } else {
        System.out.print("\033[H\033[2J");
        System.out.flush();
      }
    } catch (Exception e) {
      logger.warn("ConsoleView", "Очистка консоли не удалась: " + e.getMessage());
      fallbackClear(); // ← запасной способ
    }
  }

  private static void fallbackClear() {
    for (int i = 0; i < 50; i++) {
      System.out.println();
    }
  }
}
