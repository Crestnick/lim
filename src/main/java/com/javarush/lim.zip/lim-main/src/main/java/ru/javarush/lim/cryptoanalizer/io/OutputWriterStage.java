package ru.javarush.lim.cryptoanalizer.io;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.nio.file.Path;
import java.util.concurrent.BlockingQueue;

public class OutputWriterStage implements PipelineStage {

  private final Path outputFile;
  private final BlockingQueue<Character> inputQueue;
  private final char poisonPill;

  public OutputWriterStage(Path outputFile,
      BlockingQueue<Character> inputQueue,
      char poisonPill) {
    this.outputFile = outputFile;
    this.inputQueue = inputQueue;
    this.poisonPill = poisonPill;
  }

  @Override
  public void run() throws Exception {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile.toFile()))) {
      while (true) {
        char c = inputQueue.take();
        if (c == poisonPill) {
          break;
        }
        writer.write(c);
      }
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException("Поток записи был прерван", e);
    } catch (Exception e) {
      throw new IllegalStateException("Ошибка при записи в файл", e);
    }
  }
}
