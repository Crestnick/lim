package ru.javarush.lim.cryptoanalizer;

import java.util.ArrayList;
import java.util.List;
import ru.javarush.lim.cryptoanalizer.util.alphabet.Alphabet;
import ru.javarush.lim.cryptoanalizer.util.alphabet.AlphabetSet.AlphabetData;
import ru.javarush.lim.cryptoanalizer.util.cipher.Caesar;
import ru.javarush.lim.cryptoanalizer.util.cipher.Crypt;
import ru.javarush.lim.cryptoanalizer.util.logger.Logger;
import ru.javarush.lim.cryptoanalizer.util.logger.LoggerSingleton;

public class Main {

  private static final Logger logger = LoggerSingleton.getInstance();

  public static void main(String[] args) {
    logger.error("USER", "TEST");
    logger.debug("Main", "Start");
    logger.info("Программа запущена...");

    try {
      Alphabet letters = () -> {
        List<Character> symbols = new ArrayList<>();

        for (char letter = 'А'; letter <= 'Я'; letter++) {
          symbols.add(letter);
          if (letter == 'Е') {
            symbols.add('Ё');
          }
        }
        for (char letter = 'а'; letter <= 'я'; letter++) {
          symbols.add(letter);
          if (letter == 'е') {
            symbols.add('ё');
          }
        }

        symbols.addAll(List.of('.', ',', '"', '\'', ':', '-', '!', '?', ' '));

        return symbols;
      };

      AlphabetData russian = letters.buildRecord(letters.generate());

      Crypt caesar = new Caesar(russian);
      Controller controller = new Controller(caesar, russian);
      controller.run();

    } catch (Exception e) {
      logger.exception("Main", "❌ Unexpected error", e);
    }

    logger.debug("Main", "End");
  }
}
