package ru.javarush.lim.cryptoanalizer.io;

import java.util.Optional;
import java.util.Scanner;
import java.util.function.Function;
import ru.javarush.lim.cryptoanalizer.ui.ConsoleView;
import ru.javarush.lim.cryptoanalizer.util.logger.Logger;
import ru.javarush.lim.cryptoanalizer.util.logger.LoggerSingleton;

public class InputConsole {

  private static final Logger logger = LoggerSingleton.getInstance();
  private static final Scanner INPUT = new Scanner(System.in);

  private InputConsole() {
  }

  public enum Flag {
    USER("Выберите пункт меню:", "Пример: 1 — Шифрование, 2 — Дешифровка, 3 — Выход"),
    KEY("Введите ключ:", "Пример: 5"),
    PATH("Введите путь к файлу:", "Пример: C:/Users/Dmitriy/Documents/input.txt");

    private final String prompt;
    private final String example;

    Flag(String prompt, String example) {
      this.prompt = prompt;
      this.example = example;
    }

    public String getPrompt() {
      return prompt;
    }

    public String getExample() {
      return example;
    }
  }

  public static Optional<Byte> rawKey(String input) {
    try {
      int value = Integer.parseInt(input);
      if (value >= -128 && value <= 127) {
        return Optional.of((byte) value);
      }
    } catch (NumberFormatException ignored) {
    }
    return Optional.empty();
  }

  public static <T> T getValidatedInput(Flag flag, Function<String, Optional<T>> parser,
      String errorMessage) {
    while (true) {
      ConsoleView.showMenu();
      logger.info(flag.getPrompt());
      logger.info(flag.getExample());
      String input = INPUT.nextLine().trim();
      Optional<T> result = parser.apply(input);
      if (result.isPresent()) {
        ConsoleView.clearConsole();
        return result.get();
      }
      logger.warn("InputConsole", "Некорректный ввод!");
      logger.fail(errorMessage);
    }
  }
}
