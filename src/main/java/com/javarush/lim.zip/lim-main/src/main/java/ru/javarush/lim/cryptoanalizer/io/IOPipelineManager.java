package ru.javarush.lim.cryptoanalizer.io;

import java.nio.file.Path;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import ru.javarush.lim.cryptoanalizer.util.alphabet.AlphabetSet.AlphabetData;
import ru.javarush.lim.cryptoanalizer.util.cipher.Crypt;
import ru.javarush.lim.cryptoanalizer.util.logger.Logger;
import ru.javarush.lim.cryptoanalizer.util.logger.LoggerSingleton;

public class IOPipelineManager {

  private static final Logger logger = LoggerSingleton.getInstance();
  private static final char POISON_PILL = '\u0000';
  private static final String TAG = "IOPipelineManager";

  private static volatile IOPipelineManager instance;

  private int total = 0;
  private int accepted = 0;
  private int skipped = 0;

  private IOPipelineManager() {
  }

  public static IOPipelineManager getInstance() {
    if (instance == null) {
      synchronized (IOPipelineManager.class) {
        if (instance == null) {
          instance = new IOPipelineManager();
        }
      }
    }
    return instance;
  }

  public void execute(Path inputFile, Path outputFile, Crypt cipher, AlphabetData alphabet,
      boolean decryptMode) {
    BlockingQueue<Character> mainQueue = new LinkedBlockingQueue<>();
    BlockingQueue<Character> resultQueue = new LinkedBlockingQueue<>();

    runStage("Фильтрация", new InputFilterStage(inputFile, alphabet, mainQueue, this, POISON_PILL));
    runStage("Трансформация",
        new TransformStage(cipher, decryptMode, mainQueue, resultQueue, POISON_PILL));
    runStage("Запись", new OutputWriterStage(outputFile, resultQueue, POISON_PILL));

    printStats(alphabet);
  }

  public void incrementTotal() {
    total++;
  }

  public void incrementAccepted() {
    accepted++;
  }

  public void incrementSkipped() {
    skipped++;
  }

  private void runStage(String name, PipelineStage stage) {
    Thread thread = new Thread(() -> {
      try {
        long start = System.nanoTime();
        stage.run();
        long duration = System.nanoTime() - start;
        logger.info("⏱ " + name + " завершена за " + (duration / 1_000_000) + " мс");
      } catch (Exception e) {
        logger.exception(TAG, "Ошибка в стадии " + name, e);
      }
    });

    thread.start();
    try {
      thread.join();
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      logger.exception(TAG, "Поток " + name + " был прерван", e);
    }
  }

  private void printStats(AlphabetData alphabet) {
    logger.info("\n📊 Статистика:");
    logger.info("🔠 Алфавит: " + alphabet.size());
    logger.info("📄 Всего символов: " + total);
    logger.info("✅ Принято: " + accepted);
    logger.info("❌ Пропущено: " + skipped);
  }
}
