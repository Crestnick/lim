package ru.javarush.lim.cryptoanalizer.util.cipher;

import ru.javarush.lim.cryptoanalizer.util.alphabet.AlphabetSet.AlphabetData;
import ru.javarush.lim.cryptoanalizer.util.logger.Logger;
import ru.javarush.lim.cryptoanalizer.util.logger.LoggerSingleton;

public class Caesar implements Crypt, CryptKey {

  private static final Logger logger = LoggerSingleton.getInstance();
  private final AlphabetData context;
  private int shift = 0;

  public Caesar(AlphabetData set) {
    this.context = set;

  }

  @Override
  public void acceptKey(byte key) {
    int alphabetSize = context.size();
    this.shift = ((key % alphabetSize) + alphabetSize) % alphabetSize;
  }

  @Override
  public char encrypt(char input) {
    if (!context.contains(input)) {
      return input;
    }
    int index = context.indexOf(input);
    int newIndex = (index + shift) % context.size();
    return context.get(newIndex);
  }

  @Override
  public char decrypt(char input) {
    if (!context.contains(input)) {
      return input;
    }
    int index = context.indexOf(input);
    int newIndex = (index - shift + context.size()) % context.size();
    return context.get(newIndex);
  }
}

