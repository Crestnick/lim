package ru.javarush.lim.cryptoanalizer.util.validator;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class OutputDirectoryValidator {

  private OutputDirectoryValidator() {
  }

  public static Path validate(String input) throws IOException {
    Path path = Paths.get(input.trim());

    if (Files.exists(path)) {
      if (!Files.isDirectory(path)) {
        throw new IOException("❌ Указанный путь существует, но не является папкой: " + path);
      }
    } else {

      Files.createDirectories(path);
    }

    return path;
  }
}
