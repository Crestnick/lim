package ru.javarush.lim.cryptoanalizer.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Path;
import java.util.concurrent.BlockingQueue;
import ru.javarush.lim.cryptoanalizer.util.alphabet.AlphabetSet.AlphabetData;

public class InputFilterStage implements PipelineStage {

  private final Path inputFile;
  private final AlphabetData context;
  private final BlockingQueue<Character> outputQueue;
  private final IOPipelineManager manager;
  private final char poisonPill;

  public InputFilterStage(Path inputFile,
      AlphabetData context,
      BlockingQueue<Character> outputQueue,
      IOPipelineManager manager,
      char poisonPill) {
    this.inputFile = inputFile;
    this.context = context;
    this.outputQueue = outputQueue;
    this.manager = manager;
    this.poisonPill = poisonPill;
  }

  @Override
  public void run() throws Exception {
    try (BufferedReader reader = new BufferedReader(new FileReader(inputFile.toFile()))) {
      int ch;
      while ((ch = reader.read()) != -1) {
        manager.incrementTotal();
        char c = (char) ch;

        if (Character.isISOControl(c) || !Character.isDefined(c)) {
          manager.incrementSkipped();
          continue;
        }

        if (context.contains(c)) {
          outputQueue.put(c);
          manager.incrementAccepted();
        } else {
          manager.incrementSkipped();
        }
      }
      outputQueue.put(poisonPill);
    }
  }
}
