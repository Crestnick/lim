package ru.javarush.lim.cryptoanalizer.util.alphabet;

import java.util.List;

@FunctionalInterface
public interface Alphabet extends AlphabetSet {

  List<Character> generate();

}